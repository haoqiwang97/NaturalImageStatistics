#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 21:50:15 2020

@author: haoqiwang
"""


from matplotlib import pyplot as plt

import cv2

import imageio


IMAGE_FOLDER = './image_database/'
image_name = 'cps201004291795.ppm'

image_path = IMAGE_FOLDER + image_name

#plt.imread(image_path)
img16 = cv2.imread(image_path,-1)
img8 = (img16/256).astype('uint8')
img8 = cv2.cvtColor(img8, cv2.COLOR_BGR2RGB)

plt.imshow(img8)
#plt.axis('off')

# save unit8 image
image_save_name=image_name[:-4]+'.jpg'
imageio.imwrite(image_save_name, img8)

saved_image=plt.imread(image_save_name)
plt.imshow(saved_image)

im22=img16.astype('unit8')
